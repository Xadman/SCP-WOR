﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

namespace aSlot {

[System.Serializable]
public class BetsWrapper
{
	public int value;
	public bool canBet;
}

}